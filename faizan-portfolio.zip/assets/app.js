
(function(){
var $=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))},H=document.documentElement,
RM=matchMedia('(prefers-reduced-motion: reduce)').matches,FINE=matchMedia('(pointer:fine)').matches,cl=function(v,a,b){return Math.min(b,Math.max(a,v))};
if(RM)H.classList.add('rm');
try{var t=localStorage.getItem('th');if(t)H.dataset.theme=t}catch(e){}
$('#tg')[0].onclick=function(){var n=H.dataset.theme=='dark'?'light':'dark';H.dataset.theme=n;try{localStorage.setItem('th',n)}catch(e){}};
/* reveals: toggled on enter AND exit, so they replay both directions */
var io=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('in',e.isIntersecting)})},{threshold:.12});
var mp=new Map(),io2=new IntersectionObserver(function(es){es.forEach(function(e){mp.get(e.target).forEach(function(t){t.classList.toggle('in',e.isIntersecting)})})},{rootMargin:'-8% 0px -8% 0px'});
function obs(e){if(e.dataset.r=='c'||e.dataset.r=='w'){var p=e.parentElement;if(!mp.has(p)){mp.set(p,[]);io2.observe(p)}mp.get(p).push(e)}else io.observe(e)}
$('[data-r]').forEach(obs);
/* counters: replay each time the section is re-entered */
function run(el){var T=+el.dataset.t,s=performance.now();cancelAnimationFrame(el._f);(function f(n){var p=cl((n-s)/1400,0,1);el.textContent=Math.round(T*(1-Math.pow(1-p,3)));if(p<1)el._f=requestAnimationFrame(f)})(s)}
var co=new IntersectionObserver(function(es){es.forEach(function(e){var el=e.target;if(e.isIntersecting){RM?el.textContent=el.dataset.t:run(el)}else{cancelAnimationFrame(el._f);el.textContent=0}})},{threshold:.5});
$('.cn').forEach(function(e){co.observe(e)});
/* words */
['ih','ip'].forEach(function(id){var e=document.getElementById(id);e.innerHTML=e.textContent.split(' ').map(function(w){return'<span class="wd">'+w+'</span>'}).join(' ')});
var wds=$('#intro .wd'),sk=$('#svc')[0],tt=$('.st .h'),pn=$('.pn'),sb=$('#sb')[0],par=$('[data-s]'),mq=$('#mq')[0],ph=$('#ph .ln'),hl=$('.hl span'),pt=$('#pt')[0],hs=$('#hs')[0],pb=$('#pb')[0],nav=$('#nav'),ai=$('#aimg')[0],trk=$('#trk')[0],last=-1;
$('.cn').forEach(function(e){e.textContent=0});
function svcSet(i){if(i==last)return;last=i;tt.forEach(function(x,k){x.classList.toggle('a',k==i)});pn.forEach(function(x,k){x.classList.toggle('a',k==i)})}
tt.forEach(function(x){x.onclick=function(){var r=sk.getBoundingClientRect(),h=sk.offsetHeight-innerHeight;scrollTo({top:scrollY+r.top+h*(+x.dataset.i+.5)/3})}});
function tick(){try{tk()}catch(e){}requestAnimationFrame(tick)}function tk(){var y=scrollY,vh=innerHeight,home=!document.body.classList.contains('vc');
nav[0].classList.toggle('s',y>40);pb.style.width=(y/(document.body.scrollHeight-vh)*100)+'%';
if(home&&!RM){
var p=cl(y/vh,0,1);
hl.forEach(function(s,i){s.style.transform='translateX('+((i%2?1:-1)*p*10)+'vw)'});
pt.style.transform='translateY('+(-p*9)+'vh) scale('+(1+p*.14)+')';pt.style.opacity=1-p*.7;hs.style.opacity=1-p*1.1;
par.forEach(function(e){var r=e.getBoundingClientRect();e.style.transform='translateY('+((r.top+r.height/2-vh/2)*-e.dataset.s)+'px)'});
wds.forEach(function(w,i){var r=w.getBoundingClientRect(),c=(r.top-vh*.82)/(vh*.5),o=cl(1-c,0,1);w.style.color=o>.6?'var(--fg)':'var(--mut)';w.style.transform='translateX('+((i%2?1:-1)*cl((r.top-vh*.5)/vh,0,1)*30)+'px)'});
mq.style.transform='translateX('+(-y*.25%1400)+'px)';
var r=sk.getBoundingClientRect(),pr=cl(-r.top/(sk.offsetHeight-vh),0,.999);svcSet(Math.floor(pr*3));sb.style.width=(pr*100)+'%';
var pr2=$('#phil')[0].getBoundingClientRect(),q=(vh/2-(pr2.top+pr2.height/2))/vh;ph.forEach(function(l,i){var o=cl(1-Math.abs(q*2.2+(1.5-i)*.35-.3),.15,1);l.style.opacity=o;l.style.transform='translateX('+((i%2?1:-1)*q*60)+'px)'});
var sr=trk.parentNode.getBoundingClientRect();trk.style.transform='translateX('+((sr.top-vh)*.35)+'px)';var ar=ai.parentNode.getBoundingClientRect();ai.style.transform='translateY('+((ar.top-vh/2)*-.05)+'px) scale('+(1.05+cl((vh-ar.top)/vh,0,1)*.08)+')'}
else{svcSet(0)}}
tick();
/* skills */
var sks=[['Digital Marketing','APPLYING'],['Content Creation','APPLYING'],['Social Media','APPLYING'],['SEO','LEARNING'],['Meta Ads','PRACTICING'],['Branding','BUILDING'],['UGC','PRACTICING'],['Marketing Strategy','LEARNING'],['Business Setup','BUILDING'],['Creative Direction','BUILDING'],['AI Tools','APPLYING']];
$('#tags')[0].innerHTML=sks.map(function(s,i){return'<div class="tag" data-r data-d="'+(i%4)+'">'+s[0]+'<small>'+s[1]+'</small></div>'}).join('');
$('.tag').forEach(obs);
/* hire */
var need='Content creation',ms=$('#msg')[0];function upd(){var m="Hi Faizan, I'm looking for help with "+need.toLowerCase()+". Here's what I'm building: ";ms.textContent=m;$('#wa')[0].href='https://wa.me/923024430774?text='+encodeURIComponent(m)}
$('.chip').forEach(function(c){c.onclick=function(){$('.chip').forEach(function(x){x.setAttribute('aria-pressed',x==c)});need=c.textContent;upd()}});upd();
/* menu */
var mm=$('#mm')[0],bg=$('#bg')[0];bg.onclick=function(){mm.classList.toggle('o')};$('a',mm).forEach(function(a){a.onclick=function(){mm.classList.remove('o')}});
/* routing: certificates live on their own page view */
function route(){var h=location.hash.slice(1),c=h=='certificates';document.body.classList.toggle('vc',c);
if(c){scrollTo(0,0);$('#certs [data-r]').forEach(function(e){e.classList.remove('in');setTimeout(function(){e.classList.add('in')},60)})}
else if(h&&h!='top'){setTimeout(function(){var e=document.getElementById(h);if(e){if(h=='svc'){scrollTo({top:e.getBoundingClientRect().top+scrollY})}else e.scrollIntoView()}},60)}
else if(h=='top')scrollTo(0,0)}
addEventListener('hashchange',route);route();
$('#certs [data-r]').forEach(obs);
var lb=$('#lb')[0];$('.cc img').forEach(function(i){i.onclick=function(){lb.firstChild.src=i.src;lb.classList.add('o')}});lb.onclick=function(){lb.classList.remove('o')};

$('.pat').forEach(function(s){s.addEventListener('mousemove',function(e){var r=s.getBoundingClientRect();s.style.setProperty('--mx',(e.clientX-r.left)+'px');s.style.setProperty('--my',(e.clientY-r.top)+'px')})});
$('.wk').forEach(function(w){w.onclick=function(){var im=w.querySelector('img');if(im){lb.firstChild.src=im.src;lb.classList.add('o')}else if(w.querySelector('svg')){location.hash='';document.getElementById('case').scrollIntoView()}}});
/* cursor + magnetic buttons (desktop only) */
if(FINE&&!RM){var cu=$('#cur')[0],x=0,y2=0,cx=0,cy=0;addEventListener('mousemove',function(e){x=e.clientX;y2=e.clientY});(function m(){cx+=(x-cx)*.22;cy+=(y2-cy)*.22;cu.style.transform='translate('+cx+'px,'+cy+'px)';requestAnimationFrame(m)})();
$('a,button,[data-c]').forEach(function(e){e.addEventListener('mouseenter',function(){cu.classList.add('g')});e.addEventListener('mouseleave',function(){cu.classList.remove('g')})});
$('.mag').forEach(function(b){b.addEventListener('mousemove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+(e.clientX-r.left-r.width/2)*.25+'px,'+(e.clientY-r.top-r.height/2)*.35+'px)'});b.addEventListener('mouseleave',function(){b.style.transform=''})})}
})();
