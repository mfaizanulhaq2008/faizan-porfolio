# M Faizan Ul Haq — Portfolio

Static site (HTML, CSS, JS). No build step.

## Put it on GitHub
1. Create a new empty repository on github.com (for example `faizan-portfolio`).
2. Upload everything inside this folder (drag and drop works: "Add file" > "Upload files"), or from a terminal:
   `git init && git add . && git commit -m "Portfolio" && git branch -M main && git remote add origin <your-repo-url> && git push -u origin main`

## Deploy on Vercel
1. Go to vercel.com > Add New > Project > Import your GitHub repository.
2. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Click Deploy.
3. Every push to `main` redeploys automatically. Add a custom domain under Project > Settings > Domains.

## Edit later
- Text: `index.html`
- Colours and layout: `assets/style.css` (colour tokens near the top)
- Images: `assets/img/` (replace files, keep names)
- To use your real Ora logo: replace the `#oralogo` SVG symbol in `index.html` with an `<img>` tag.
